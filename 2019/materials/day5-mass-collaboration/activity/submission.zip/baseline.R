# baseline.R
# Example FFC submission (GPA only)
# Author: Alex Kindel
# Date: 17 June 2019

library(dplyr)

# Read in the data
data.dir <- "/Users/AK/Code/sicss/"
train <- read.csv(paste0(data.dir, "FFChallenge_v5/train.csv"))
background <- read.csv(paste0(data.dir, "FFChallenge_v5/background.csv"))
prediction <- read.csv(paste0(data.dir, "FFChallenge_v5/prediction.csv"))

# Merge training data with background variables
ffc <- left_join(train, background, by = "challengeID")

# Social psychologists theorize that feelings of belonging in school are a predictor of academc success.
# Let's predict GPA as a linear function of a belongingness measure at age 9.
# We'll leave the other outcomes at their training means.

# Regress GPA on k5e1a, "I feel like I am part of my school".
m1_gpa <- lm(gpa ~ k5e1a, data=ffc)

# Generate predicted values for this model
# We'll fill in the mean of the training data if we're missing data
m1_gpa_pred <- predict(m1_gpa, newdata=background, type="response")
m1_gpa_pred[is.nan(m1_gpa_pred)] <- mean(prediction$gpa)
my_prediction <- prediction %>% mutate(gpa = m1_gpa_pred)  # Append new predictions

# Write predictions to CSV
write.csv(my_prediction, paste0(data.dir, "submission/prediction.csv"), row.names = F)

# After submitting:
#  - Compress prediction.csv, narrative.txt, and baseline.R into one zip file (not in an enclosing folder!)
#  - Upload to CodaLab and see how you did!