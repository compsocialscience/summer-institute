# ============================================================================
# TALLER: Mapear lo visible, narrar lo ausente
# An??lisis espacial y m??todos computacionales con enfoque feminista
# ============================================================================
#
# OBJETIVO: Explorar c??mo fen??menos sociales (pol??ticos, de violencia,
# econ??micos) se distribuyen territorialmente en Colombia y qu?? historias
# quedan AUSENTES en los datos que recolectamos.
#
# ESTRUCTURA (1h 15min):
# Parte 1 (25 min): Estad??stica descriptiva de datos del DNP
# Parte 2 (25 min): An??lisis electoral y fragmentaci??n pol??tica
# Parte 3 (25 min): An??lisis espacial e inferencial

# INSTALACI??N DE LIBRER??AS NECESARIAS (correr solo una vez)
# install.packages(c("tidyverse", "sf", "leaflet", "viridis", "ggplot2",
#                   "corrplot", "gridExtra"))

# ============================================================================
# CONFIGURACI??N INICIAL
# ============================================================================


#Instalar paquetes
#install.packages("")

# Cargar librer??as necesarias
library(tidyverse)      # Para manipulaci??n de datos y gr??ficos
library(sf)             # Para manejo de datos espaciales
library(leaflet)        # Para mapas interactivos
library(viridis)        # Paletas de colores inclusivas (accesibles)
library(ggplot2)        # Visualizaciones base
library(gridExtra)      # Poner gr??ficos lado a lado

# Establecer directorio de trabajo
 setwd("~/Documents/SICSS/Taller csv/csv_def")

# Opci??n de visualizaci??n (para ver mejor los datos)
options(digits = 2, width = 100)

# ============================================================================
# PARTE 1: ESTAD??STICA DESCRIPTIVA - DATOS DNP
# ============================================================================
#
# PREGUNTA RECTORA: ??Cu??les departamentos tienen mayor/menor violencia?
# ??Cu??les son m??s innovadores? ??D??nde hay m??s educaci??n?
# ??Qu?? departamentos quedan INVISIBLES en estos datos?


# Cargar datos del DNP (base que ya limpiamos)
# Esta base tiene 34 departamentos colombianos con indicadores de:
# - Educaci??n (cobertura en primaria, secundaria, superior)
# - Seguridad (tasas de homicidio intencional)
# - Econom??a (participaci??n PIB, ??ndice de innovaci??n)

#Dos formas: cargar base
#1. directo desde el environment
#2. construyendo un objeto con funcion read
#dnp <- read.csv("ruta.csv", encoding = "UTF-8")

# Exploraci??n r??pida
print(head(dnp, 5))
#cat es una funci??n que se utiliza para concatenar e imprimir m??ltiples 
#elementos (texto, n??meros y variables) directamente en la consola o en un archivo
cat("\nDimensiones:", nrow(dnp), "departamentos x", ncol(dnp), "variables\n")


#ESTAD??STICA DESCRIPTIVA (LECTURA MACRO)

# === DESCRIPTIVOS B??SICOS ===
#Media: Promedio de los valores
#Moda: El valor que m??s se repite en los datos
#Mediana: El valor del medio cuando los datos est??n ordenados
#Desviaci??n est??ndar: Mide cu??nto se dispersan los datos

# Vamos a hacer un resumen estad??stico de las variables principales
# Seleccionar variables clave para an??lisis
# dplyr es un paquete que facilita manipulaci??n de datos
#dplyr::select 


dnp_analisis <- dnp %>%
  dplyr::select(
    Departamento,
    homicidios = SEG_HOMICIDIO_INTENCIONAL_POR_CADA_100.000_H,
    educacion = EDU_EN_EDUCACION_SUPERIOR,
    innovacion = ECO_PUNTAJE_DEL_IDIC
  ) %>%
  filter(!is.na(homicidios) | !is.na(educacion) | !is.na(innovacion))

#Resumenes estad??sticos
#Summary es una funci??n que te muestra las medidas estad??sticas
#El signo $ es un operador de extracci??n o selecci??n

summary(dnp_analisis$homicidios)
summary(dnp_analisis$educacion)
summary(dnp_analisis$innovacion)

# psych es una librer??a de an??lisis de datos, hay diferentes que pueden usar
# Describe() muestra todos los estad??sticos autom??ticamente (con otra librer??a)
psych::describe(dnp_analisis[, c("homicidios", "educacion", "innovacion")])


# === IDENTIFICAR DEPARTAMENTOS EXTREMOS ===
# Esto es importante para ver qu?? departamentos son "OUTLIERS"
# (valores muy diferentes al promedio)

#En el caso de esta variable, estamos analizando cierto n??mero de casos por cada 100 mil habitantes
dnp_analisis %>%
  arrange(desc(homicidios)) %>%
  slice(1:5) %>%
  dplyr::select(Departamento, homicidios) %>%
  print()

#DEPARTAMENTOS CON M??NIMOS HOMICIDIOS
dnp_analisis %>%
  arrange(homicidios) %>%
  slice(1:5) %>%
  dplyr::select(Departamento, homicidios) %>%
  print()


#El ??ndice de innovaci??n es sobre 100
#DEPARTAMENTOS M??S INNOVADORES 
dnp_analisis %>%
  arrange(desc(innovacion)) %>%
  slice(1:5) %>%
  dplyr::select(Departamento, innovacion) %>%
  print()

#??Cu??les son los gr??ficos que podr??an hacerse para comparar?






# === GR??FICO 1: BOXPLOT (para ver OUTLIERS) ===
# El boxplot es perfecto para identificar departamentos "anormales"
# Esos puntos fuera de los bigotes = departamentos muy diferentes

p3 <- dnp_analisis %>%
  dplyr::select(homicidios, educacion, innovacion) %>%
  pivot_longer(
    cols = everything(),
    names_to = "indicador",
    values_to = "valor"
  ) %>%
  filter(!is.na(valor)) %>%
  ggplot(aes(x = indicador, y = valor, fill = indicador)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_viridis(discrete = TRUE, option = "turbo") +
  facet_wrap(~indicador, scales = "free") +
  labs(
    title = "Distribuci??n de Indicadores (Boxplot)",
    subtitle = "Puntos aislados = departamentos OUTLIERS",
    x = "",
    y = "Valor"
  ) +
  theme_minimal() +
  theme(legend.position = "none", axis.text.x = element_blank())

print(p3)

#GR??FICOS ESPACIALES
#==========================================
# PASO 1: Descargar el mapa de Colombia
# ============================================================
## GADM = Global Administrative Divisions
# Es una base de datos MUNDIAL con los l??mites de todos los pa??ses
# "level = 1" significa: dame el nivel administrativo 1

colombia <- gadm(country = "COL", level = 1, path = tempdir())
mapa_deptos <- st_as_sf(colombia)
# st_as_sf() = "spatial table as simple features"
# Convierte el objeto GADM a un formato que R entiende como "datos espaciales"
# Ahora 'mapa_deptos' es un DATA FRAME pero CON GEOMETR??A
# = Cada fila es un departamento + sus coordenadas (l??mites)


# Limpiar nombres de departamentos
mapa_deptos <- mapa_deptos %>%
  mutate(
    Departamento = toupper(NAME_1) %>%
      iconv(from = "UTF-8", to = "ASCII//TRANSLIT") %>%
      gsub("[']", "", .) %>%
      gsub("NARI~NO", "NARINO", .) %>%  # ??? Agregar aqu??
      trimws()
  )


# ============================================================
# PASO 2: Preparar tus datos
# ============================================================
dnp_map <- dnp_analisis %>%
  mutate(Departamento = toupper(Departamento))

# ============================================================
# PASO 3: Unir datos con mapa
# ============================================================
col_datos <- mapa_deptos %>%
  left_join(dnp_map, by = "Departamento")

# ============================================================
# MAPA 1: HOMICIDIOS
# ============================================================
ggplot(col_datos) +
  geom_sf(aes(fill = homicidios), color = "white", size = 0.2) +
  scale_fill_viridis(name = "Homicidios\n(x 100.000)", direction = -1, na.value = "gray90") +
  labs(title = "Geograf??a de la Violencia en Colombia",
       subtitle = "Homicidios intencionales por departamento") +
  theme_minimal() +
  theme(axis.text = element_blank(), axis.title = element_blank())

# ============================================================
# MAPA 2: EDUCACI??N
# ============================================================
ggplot(col_datos) +
  geom_sf(aes(fill = educacion), color = "white", size = 0.2) +
  scale_fill_viridis(name = "Educaci??n\nSuperior %", direction = 1, na.value = "gray90") +
  labs(title = "Educaci??n Superior por Departamento") +
  theme_minimal() +
  theme(axis.text = element_blank(), axis.title = element_blank())

# ============================================================
# MAPA 3: INNOVACI??N
# ============================================================
ggplot(col_datos) +
  geom_sf(aes(fill = innovacion), color = "white", size = 0.2) +
  scale_fill_viridis(name = "Puntaje IDIC", direction = 1, na.value = "gray90") +
  labs(title = "Innovaci??n por Departamento") +
  theme_minimal() +
  theme(axis.text = element_blank(), axis.title = element_blank())

# ============================================================
# MAPA INTERACTIVO CON LEAFLET
# ============================================================
pal <- colorNumeric(palette = "RdYlBu", domain = col_datos$homicidios, reverse = TRUE)

col_datos <- col_datos %>%
  mutate(popup = paste(
    "<b>", Departamento, "</b><br>",
    "Homicidios: ", round(homicidios, 2), "<br>",
    "Educaci??n: ", round(educacion, 2), "%<br>",
    "Innovaci??n: ", round(innovacion, 2)
  ))

leaflet(col_datos) %>%
  addTiles() %>%
  addPolygons(
    fillColor = ~pal(homicidios),
    fillOpacity = 0.7,
    color = "white",
    weight = 2,
    popup = ~popup,
    highlight = highlightOptions(color = "#FFD700", weight = 3, bringToFront = TRUE)
  ) %>%
  addLegend("bottomright", pal = pal, values = ~homicidios, title = "Homicidios")


# === REFLEXI??N CR??TICA: LAS AUSENCIAS ===
# Contar cu??ntos datos faltantes hay en cada indicador

faltantes <- data.frame(
  indicador = c("Homicidios", "Educaci??n Superior", "Innovaci??n"),
  n_faltantes = c(
    sum(is.na(dnp_analisis$homicidios)),
    sum(is.na(dnp_analisis$educacion)),
    sum(is.na(dnp_analisis$innovacion))
  )
)

print(faltantes)

#PREGUNTA CR??TICA
#"??Qu?? significa que falten datos en ciertos departamentos?\n")
#"??Ausencia de datos = ausencia del problema o ausencia de registro?\n")

# ============================================================================
# PARTE 2: AN??LISIS ELECTORAL Y FRAGMENTACI??N POL??TICA

# === SENADO
# Fragmentaci??n por ideolog??a
# Mayor fragmentaci??n = menos consenso territorial

# Ver estructura de ideolog??a
print(senado %>% group_by(ideologia) %>%
        summarise(n_partidos = n_distinct(partido_codigo),
                  n_votos = sum(votos),
                  .groups = "drop") %>%
        arrange(desc(n_votos)))

# Fragmentaci??n por ideolog??a (ESPECTRO POL??TICO) 
frag_ideologia <- senado %>%
  group_by(ideologia) %>%
  summarise(
    n_partidos = n_distinct(partido_codigo),
    n_candidatos = n(),
    votos_totales = sum(votos),
    votos_promedio_partido = votos_totales / n_partidos,
    participacion_relativa = votos_totales / sum(senado$votos),
    .groups = "drop"
  ) %>%
  mutate(
    ideologia = fct_reorder(ideologia, desc(votos_totales))
  )

print(frag_ideologia)

#Fragmentation POR DEPTO + IDEOLOG??A (viendo desagregaci??n)

frag_depto_ideo <- senado %>%
  group_by(depto_nombre, ideologia) %>%
  summarise(
    n_partidos = n_distinct(partido_codigo),
    votos = sum(votos),
    .groups = "drop"
  ) %>%
  arrange(depto_nombre, desc(votos))

# Ver top departamentos por ideolog??a
top_deptos_por_ideo <- frag_depto_ideo %>%
  group_by(ideologia) %>%
  slice_max(votos, n = 5) %>%
  arrange(ideologia, desc(votos))

print(top_deptos_por_ideo)

# Gr??fico 1: Distribuci??n de votos por ideolog??a
g1 <- frag_ideologia %>%
  ggplot(aes(x = reorder(ideologia, -votos_totales), y = votos_totales, fill = ideologia)) +
  geom_col() +
  scale_fill_viridis(discrete = TRUE, option = "D") +
  labs(
    title = "Senado 2026: Votos totales por ideolog??a",
    x = "Ideolog??a pol??tica",
    y = "Votos totales",
    fill = "Ideolog??a"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

print(g1)

#Identificar los partidos

senado %>%
  distinct(partido_nombre, ideologia) %>%
  arrange(ideologia, partido_nombre)

# Gr??fico 2: N??mero de partidos por ideolog??a
g2 <- frag_ideologia %>%
  ggplot(aes(x = reorder(ideologia, -n_partidos), y = n_partidos, fill = ideologia)) +
  geom_col() +
  scale_fill_viridis(discrete = TRUE, option = "D") +
  labs(
    title = "Senado 2026: N??mero de partidos por ideolog??a",
    x = "Ideolog??a pol??tica",
    y = "# partidos competiendo",
    fill = "Ideolog??a"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

print(g2)

# Gr??fico 3: Heatmap - Deptos x Ideolog??a (votos)
g3 <- frag_depto_ideo %>%
  filter(!is.na(ideologia)) %>%
  arrange(desc(votos)) %>%  # Ordena deptos por votos totales
  mutate(depto_nombre = fct_reorder(depto_nombre, votos, .fun = sum)) %>%
  ggplot(aes(x = depto_nombre, y = votos, fill = ideologia)) +
  geom_col() +  # Barras apiladas
  scale_fill_viridis(discrete = TRUE, option = "D") +
  coord_flip() +
  labs(
    title = "Composici??n ideol??gica por departamento (Senado 2026)",
    subtitle = "??Qu?? ideolog??a domina en cada regi??n?",
    x = "Departamento",
    y = "Votos totales",
    fill = "Ideolog??a"
  ) +
  theme_minimal() +
  theme(axis.text.y = element_text(size = 9))

print(g3)

#=== AN??LISIS CAMARA ===

# Fragmentaci??n territorial
# ============================================================================

frag_depto <- camara %>%
  group_by(territorio_nombre) %>%
  summarise(
    n_partidos = n_distinct(partido_codigo),
    n_candidatos = n(),
    votos_totales = sum(votos, na.rm = TRUE),
    votos_promedio_partido = votos_totales / n_partidos,
    .groups = "drop"
  ) %>%
  arrange(desc(n_partidos))

print(frag_depto %>% head(20))


# ============================================================================
# GR??FICOS
# ============================================================================
# Gr??fico 2: Scatter - Fragmentaci??n vs Votos
g2 <- frag_depto %>%
  ggplot(aes(x = n_partidos, y = votos_totales, 
             label = territorio_nombre,  # Cambi?? territorio_nombre ??? depto_nombre
             size = votos_totales, 
             color = n_partidos)) +
  geom_point(alpha = 0.6) +
  geom_text(size = 3, vjust = 1.5) +
  scale_color_viridis() +
  labs(
    title = "Fragmentaci??n pol??tica vs Total de votos",
    x = "N??mero de partidos (fragmentaci??n)",
    y = "Votos totales",
    color = "# partidos",
    size = "Votos"
  ) +
  theme_minimal()

print(g2)

###OPCIONAL PARA MEJORAR EL GRAFICO

library(ggrepel)  # Para etiquetas sin solapamiento

g2 <- frag_depto %>%
  ggplot(aes(x = n_partidos, y = votos_totales, 
             label = territorio_nombre,
             size = votos_totales, 
             color = n_partidos)) +
  
  # Puntos con transparencia y separaci??n
  geom_jitter(alpha = 0.5, width = 0.3, height = 0) +
  
  # Etiquetas que no se solapan
  geom_text_repel(
    size = 3, 
    max.overlaps = Inf,
    box.padding = 0.3,
    point.padding = 0.3,
    segment.alpha = 0.3
  ) +
  
  # L??nea de tendencia
  geom_smooth(aes(color = NULL, size = NULL), 
              method = "lm", se = FALSE, 
              color = "gray30", linetype = "dashed", alpha = 0.5) +
  
  # Colores mejorados
  scale_color_gradient(
    low = "#2E86AB",  # Azul
    high = "#A23B72",  # Magenta
    name = "Fragmentaci??n"
  ) +
  
  # Tama??os
  scale_size_continuous(
    range = c(2, 8),
    name = "Votos totales",
    labels = scales::number
  ) +
  
  # Etiquetas y tema
  labs(
    title = "Fragmentaci??n pol??tica vs Participaci??n electoral",
    subtitle = "C??mara 2026: ??M??s partidos = m??s o menos votos?",
    x = "N??mero de partidos (fragmentaci??n)",
    y = "Votos totales",
    caption = "L??nea = tendencia general"
  ) +
  
  theme_minimal() +
  theme(
    plot.title = element_text(size = 14, face = "bold", hjust = 0),
    plot.subtitle = element_text(size = 11, color = "gray40", hjust = 0),
    panel.grid.major = element_line(color = "gray90"),
    panel.grid.minor = element_blank(),
    legend.position = "right",
    text = element_text(family = "sans", size = 10)
  )

print(g2)

# ============================================================================
# PARTE 3: AN??LISIS ESPACIAL
# ============================================================================

# === PREPARAR DATOS PARA MAPEO ===
# Para hacer mapas, necesitamos:
# 1. Geometr??a (l??mites de departamentos)
# 2. Datos (indicadores)
# 3. Uni??n de ambos

# Cargar mapa de Colombia desde el paquete rmap
# (para prop??sitos del taller usaremos geometr??a simplificada)

#"\nNOTA: Para un mapa real necesitamos archivo shapefile")
#"\nde l??mites departamentales.\n")
#"En producci??n usar??amos: geobr, rmap o descarga de IGAC\n")


# ============================================================================
# OPCI??N 1: Descargar shapefile de Colombia (IGAC)
# ============================================================================
# Descargar desde: https://www.igac.gov.co/
# O usar directamente con sf:

# install.packages("geodata")  # Alternativa: descarga autom??tica
library(geodata)

library(sf)           # Spatial features (vectorizado)
library(leaflet)      # Mapas interactivos
library(tidyverse)
library(viridis)


# Descargar l??mites administrativos de Colombia
colombia_gadm <- gadm(country = "COL", level = 1, path = tempdir())
mapa_deptos <- st_as_sf(colombia_gadm)
mapa_deptos <- mapa_deptos %>%
  mutate(
    NAME_1 = case_when(
      grepl("CAQUET", NAME_1) ~ "CAQUETA",
      grepl("GUAIN'IA", NAME_1) ~ "GUAINIA",
      TRUE ~ toupper(NAME_1) %>%
        iconv(from = "UTF-8", to = "ASCII//TRANSLIT") %>%
        gsub("[']", "", .) %>%
        gsub("[~]", "", .) %>%
        trimws() %>%
        gsub("\\s+", " ", .)
    )
  )

# Join: datos + geometr??as
col_datos <- mapa_deptos %>%
  left_join(dnp_clean, by = "NAME_1")

# Verificar
head(col_datos)


#Limpiar bases para hacer los matches 

diccionario_deptos <- tribble(
  ~territorio_nombre, ~NAME_1,
  "BOGOTA_DC", "BOGOTA D.C.",
  "LA_GUAJIRA", "LA GUAJIRA",
  "NORTE_SANTANDER", "NORTE DE SANTANDER",
  "SAN_ANDRES", "SAN ANDRES Y PROVIDENCIA",
  "VALLE", "VALLE DEL CAUCA",
  # ... m??s conversiones
)

# Usar as??:
camara_clean <- camara %>%
  left_join(diccionario_deptos, by = "territorio_nombre") %>%
  select(-territorio_nombre) %>%
  rename(territorio_nombre = NAME_1)


# Cuando miramos elecciones, podemos hacernos dos preguntas muy distintas:
#
#   1. ??Cu??ntos partidos compiten de verdad?     ??? PLURALIDAD
#   2. ??Qu?? tan divididos est??n ideol??gicamente? ??? POLARIZACI??N
#
# Son preguntas distintas y pueden dar respuestas distintas.
# Un departamento puede tener MUCHOS partidos pero todos de centro
# (alta pluralidad, baja polarizaci??n), o puede tener POCOS partidos
# pero uno de izquierda y uno de derecha enfrentados
# (baja pluralidad, alta polarizaci??n).


# Estos ??ndices SIMPLIFICAN la realidad. Hay que preguntarse:

#   ??Qui??n clasific?? a los partidos en esas ideolog??as?
#   La escala Izquierda-Derecha es una construcci??n occidental.
#   Muchos partidos colombianos son dif??ciles de ubicar en ella.

# ============================================================================
# GR??FICO 1: Polarizaci??n*
# ============================================================================

# Limpiar nombres del shapefile para que coincidan con tu base
mapa_deptos <- mapa_deptos %>%
  mutate(
    depto = case_when(
      grepl("CAQUET",   NAME_1, ignore.case = TRUE) ~ "CAQUETA",
      grepl("GUAIN",    NAME_1, ignore.case = TRUE) ~ "GUAINIA",
      grepl("Bogot",    NAME_1, ignore.case = TRUE) ~ "BOGOTA D.C.",
      TRUE ~ toupper(NAME_1) %>%
        iconv(from = "UTF-8", to = "ASCII//TRANSLIT") %>%
        gsub("[']|[~]", "", .) %>%
        trimws() %>%
        gsub("\\s+", " ", .)
    )
  )

col_mapa <- mapa_deptos %>%
  left_join(base_indices, by = "depto")


# ============================================================================
# MAPA 1: PLURALIDAD (HHI)
# ============================================================================
g1 <- ggplot(col_mapa) +
  geom_sf(aes(fill = hhi), color = "white", size = 0.2) +
  scale_fill_viridis(
    name      = "Pluralidad\n(HHI)",
    direction = 1,
    na.value  = "gray90",
    limits    = c(0, 1)
  ) +
  labs(
    title    = "Pluralidad Electoral ??? C??mara 2026",
    subtitle = "Verde = muchos partidos compiten  |  Morado = un partido domina",
    caption  = "HHI: 1 = m??xima pluralidad"
  ) +
  theme_minimal() +
  theme(
    axis.text        = element_blank(),
    axis.title       = element_blank(),
    plot.title       = element_text(face = "bold", size = 14),
    plot.subtitle    = element_text(size = 10, color = "gray40")
  )

print(g1)

# ============================================================================
# MAPA 2: POLARIZACI??N
# ============================================================================
g2 <- ggplot(col_mapa) +
  geom_sf(aes(fill = polarizacion), color = "white", size = 0.2) +
  scale_fill_distiller(
    name      = "Polarizaci??n",
    palette   = "RdYlBu",
    direction = -1,
    na.value  = "gray90"
  ) +
  labs(
    title    = "Polarizaci??n Electoral ??? C??mara 2026",
    subtitle = "Rojo = Izquierda vs Derecha enfrentadas  |  Azul = voto de centro",
    caption  = "Desviaci??n est??ndar ideol??gica ponderada por votos"
  ) +
  theme_minimal() +
  theme(
    axis.text        = element_blank(),
    axis.title       = element_blank(),
    plot.title       = element_text(face = "bold", size = 14),
    plot.subtitle    = element_text(size = 10, color = "gray40")
  )

print(g2)

# ============================================================================
# MAPA 3: % VOTOS EXTREMOS
# ============================================================================
g3 <- ggplot(col_mapa) +
  geom_sf(aes(fill = pct_extremos), color = "white", size = 0.2) +
  scale_fill_distiller(
    name      = "% Votos\nextremos",
    palette   = "RdYlGn",
    direction = -1,
    labels    = scales::percent,
    na.value  = "gray90"
  ) +
  labs(
    title    = "Voto en Extremos del Espectro ??? C??mara 2026",
    subtitle = "% que vota a Izquierda pura O Derecha pura",
    caption  = "Excluye Centro, Centroizquierda y Centroderecha"
  ) +
  theme_minimal() +
  theme(
    axis.text        = element_blank(),
    axis.title       = element_blank(),
    plot.title       = element_text(face = "bold", size = 14),
    plot.subtitle    = element_text(size = 10, color = "gray40")
  )

print(g3)


# ============================================================================
# MAPA INTERACTIVO: PLURALIDAD + POLARIZACI??N (leaflet)
# ============================================================================
pal_hhi <- colorNumeric("Greens", domain = col_mapa$hhi, na.color = "gray90")
pal_pol <- colorNumeric("RdYlBu", domain = col_mapa$polarizacion, reverse = TRUE, na.color = "gray90")

col_mapa <- col_mapa %>%
  mutate(
    popup_info = paste0(
      "<b>", depto, "</b><br>",
      "<hr style='margin:4px 0'>",
      "??????? Partidos: <b>", n_partidos, "</b><br>",
      "???? Pluralidad (HHI): <b>", round(hhi, 3), "</b><br>",
      "??? Polarizaci??n: <b>", round(polarizacion, 3), "</b><br>",
      "??????? Posici??n prom.: <b>", round(posicion_promedio, 2),
      "</b> (-2=Izq, 0=Centro, +2=Der)<br>",
      "???? % Votos extremos: <b>", round(100 * pct_extremos, 1), "%</b><br>",
      "???? Ideolog??a ganadora: <b>", ideologia_dominante, "</b>"
    )
  )

mapa_interactivo <- leaflet(col_mapa) %>%
  addTiles() %>%
  # Capa 1: Pluralidad
  addPolygons(
    fillColor   = ~pal_hhi(hhi),
    fillOpacity = 0.75,
    color       = "white",
    weight      = 2,
    popup       = ~popup_info,
    highlight   = highlightOptions(color = "#FFD700", weight = 3, bringToFront = TRUE),
    group       = "Pluralidad (HHI)"
  ) %>%
  # Capa 2: Polarizaci??n
  addPolygons(
    fillColor   = ~pal_pol(polarizacion),
    fillOpacity = 0.75,
    color       = "white",
    weight      = 2,
    popup       = ~popup_info,
    highlight   = highlightOptions(color = "#FFD700", weight = 3, bringToFront = TRUE),
    group       = "Polarizaci??n"
  ) %>%
  # Leyendas
  addLegend("bottomleft", pal = pal_hhi, values = ~hhi,
            title = "Pluralidad (HHI)", opacity = 0.75,
            group = "Pluralidad (HHI)") %>%
  addLegend("bottomright", pal = pal_pol, values = ~polarizacion,
            title = "Polarizaci??n", opacity = 0.75,
            group = "Polarizaci??n") %>%
  # Control de capas (puedes alternar entre ??ndices)
  addLayersControl(
    baseGroups    = c("Pluralidad (HHI)", "Polarizaci??n"),
    options       = layersControlOptions(collapsed = FALSE)
  )

print(mapa_interactivo)



###OPCIONAL PARA MEDIR CORRELACI??N

# === CORRELACI??N: ??Se relaciona la ideolog??a con violencia? ===
# Hacer an??lisis inferencial b??sico

# Preparar datos para correlaci??n
# Calcular % de votos por ideolog??a por depto (SENADO)
votos_ideologia <- senado %>%
  group_by(depto_nombre, ideologia) %>%
  summarise(votos = sum(votos), .groups = "drop") %>%
  pivot_wider(
    names_from = ideologia,
    values_from = votos,
    values_fill = 0
  ) %>%
  mutate(
    total_votos = Centro + Derecha + Izquierda + Otros,
    pct_izquierda = Izquierda / total_votos,
    pct_centro = Centro / total_votos,
    pct_derecha = Derecha / total_votos
  )

# Unir con homicidios e innovaci??n
datos_ideologia <- dnp %>%
  mutate(
    depto_nombre = Departamento,
    homicidios = SEG_HOMICIDIO_INTENCIONAL_POR_CADA_100.000_H,
    innovacion = ECO_PUNTAJE_DEL_IDIC
  ) %>%
  left_join(votos_ideologia, by = "depto_nombre") %>%
  dplyr::select(depto_nombre, homicidios, innovacion, 
                pct_izquierda, pct_centro, pct_derecha) %>%
  filter(!is.na(homicidios) & !is.na(pct_izquierda))

# Matriz de correlaci??n
cor_ideologia <- datos_ideologia %>%
  dplyr::select(homicidios, innovacion, pct_izquierda, pct_centro, pct_derecha) %>%
  cor(use = "complete.obs")

print(round(cor_ideologia, 2))

# Gr??fico
library(corrplot)
corrplot(
  cor_ideologia,
  method = "circle",
  type = "upper",
  addCoef.col = "black",
  col = colorRampPalette(c("#2E86AB", "white", "#A23B72"))(200),
  main = "Correlaciones: Violencia, Innovaci??n, Ideolog??a"
)

# === GR??FICO 6: DISPERSI??N (Scatter plot) ===
# Visualizar la relaci??n entre dos variables
p5 <- datos_correlacion %>%
  ggplot(aes(x = n_partidos, y = homicidios, label = depto_nombre)) +
  geom_point(size = 3, alpha = 0.6, color = "darkred") +
  geom_smooth(method = "lm", se = FALSE, color = "blue", linetype = "dashed") +
  labs(
    title = "??Se relacionan fragmentaci??n y homicidios?",
    x = "N??mero de partidos (Fragmentaci??n)",
    y = "Tasa de homicidios",
    subtitle = "L??nea azul = tendencia general",
    caption = "Si los puntos siguen la l??nea = S?? se relacionan"
  ) +
  theme_minimal()

print(p5)



