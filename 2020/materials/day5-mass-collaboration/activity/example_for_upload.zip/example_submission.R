
# example_submission.R
# Example Fragile Families Challenge submission
# Author: Ian Lundberg

# Set working directory
setwd("/Users/iandl/Dropbox/ffchallenge_SICSS_2020")

# Load packages
library(tidyverse)
library(haven)

# Load the example prepared data file
load("example_prepared_data/example_prepared_data.Rdata")

# Load the example prediction file
prediction_example <- read_csv("FFChallenge_v5/prediction.csv")

# Fit an OLS model for GPA
gpa_fit <- lm(gpa ~ cm1relf + cm1edu + cm1ethrace + 
                gpa_related_lag_teacher_rating,
              data = example_prepared_data)

# Make a data frame with our predictions
our_predictions <- example_prepared_data %>%
  # Replace the gpa variable with predicted values
  mutate(gpa = predict(gpa_fit, type = "response", newdata = example_prepared_data)) %>%
  # Select only the identifier and the outcome we have predicted
  select(challengeID, gpa)

# To upload to the submission site, you will need valid predictions for all 6 outcomes.
# We recommend using our example prediction file for the outcomes that are not your focus.
# The following steps illustrate this.

# Replace GPA predictions in the prediction file
# with predicted values from our model
prediction <- prediction_example %>%
  # Remove the outcome for which we have build a model
  select(-gpa) %>%
  # Merge in our predictions for that oucome
  left_join(our_predictions, by = "challengeID")

# Save the predictions for uploading
write_csv(prediction, path = "example_submission/prediction.csv")

# To submit:
#  - Compress prediction.csv, narrative.txt, and baseline.R into one zip file (not in an enclosing folder!)
#  - On a Mac, you can do this by highlighting these three files, right-clicking, and clicking "compress".
#  - See our example of the zip file: example_submission/example_for_upload.zip
#  - Upload to CodaLab and see your leaderboard score!